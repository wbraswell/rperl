package RPerl::Test::Bar;
1;
