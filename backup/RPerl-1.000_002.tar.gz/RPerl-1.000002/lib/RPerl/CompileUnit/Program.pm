package RPerl::CompileUnit::Program;
use strict;
use warnings;
use RPerl;
our $VERSION = 0.000_001;

use parent qw(RPerl::CompileUnit);
our %properties = (); ## no critic qw(ProhibitPackageVars)  # USER DEFAULT 3: allow OO properties

1;
