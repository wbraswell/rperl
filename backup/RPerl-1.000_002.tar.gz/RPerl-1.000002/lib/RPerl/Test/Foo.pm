package RPerl::Test::Foo;
1;
