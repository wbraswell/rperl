#ifndef __CPP__INCLUDED__rperlgmp_h
#define __CPP__INCLUDED__rperlgmp_h 0.004_000

#include <RPerl/DataType/GMPInteger.cpp>  // -> GMPInteger.h
#include <RPerl/Operation/Expression/Operator/GMPFunctions.cpp>  // -> GMPFunctions.h

#endif
