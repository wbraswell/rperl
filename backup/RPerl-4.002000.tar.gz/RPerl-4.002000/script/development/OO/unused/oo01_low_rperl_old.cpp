//!/usr/bin/rperl

// [[[ HEADER ]]]
#include <rperlstandalone.h>
#ifndef __CPP__INCLUDED__oo01_low_rperl_old_cpp
#define __CPP__INCLUDED__oo01_low_rperl_old_cpp 0.001_000
# ifdef __CPP__TYPES




// [[[ INCLUDES ]]]
#include "oo01_low_rperl_old.h"
int main() {
    // [[[ OPERATIONS HEADER ]]]

// [[[ OPERATIONS ]]]
    MyClass01LowRPerlOld_ptr my_object(new MyClass01LowRPerlOld);
    my_object->set_bar(22);
    print "have $my_object->get_bar() = " << my_object->get_bar() << endl;
    my_object->double_bar_save();
    print "have $my_object->get_bar() = " << my_object->get_bar() << endl;
    print "have $my_object->double_bar_return() = " << my_object->double_bar_return() << endl;
    print "have $my_object->get_bar() = " << my_object->get_bar() << endl;
    MySubclass01LowRPerlOld_ptr my_object_subclass(new MySubclass01LowRPerlOld);
    my_object_subclass->set_bar(33);
    print "have $my_object_subclass->get_bar() = " << my_object_subclass->get_bar() << endl;
    print "have $my_object_subclass->get_bax() = " << my_object_subclass->get_bax() << endl;
    my_object_subclass->triple_bax_save();
    print "have $my_object_subclass->get_bax() = " << my_object_subclass->get_bax() << endl;
    print "have $my_object_subclass->triple_bax_return() = " << my_object_subclass->triple_bax_return() << endl;
    print "have $my_object_subclass->get_bax() = " << my_object_subclass->get_bax() << endl;
    print "have $my_object_subclass->multiply_bax_return(2) = " << my_object_subclass->multiply_bax_return(2) << endl;
    print "have $my_object_subclass->get_bax() = " << my_object_subclass->get_bax() << endl;
    print "have $my_object_subclass->multiply_bax_return(20) = " << my_object_subclass->multiply_bax_return(20) << endl;
    print "have $my_object_subclass->get_bax() = " << my_object_subclass->get_bax() << endl;



    // [[[ OPERATIONS FOOTER ]]]
    return 0;
}

// [[[ FOOTER ]]]
# elif defined __PERL__TYPES
Purposefully_die_from_a_compile-time_error,_due_to____PERL__TYPES_being_defined.__We_need_to_define_only___CPP__TYPES_in_this_file!
# endif
#endif
