# [[[ HEADER ]]]
package RPerl::DataType;
use strict;
use warnings;
our $VERSION = 0.001_000;

# [[[ INCLUDES ]]]
# include modifiers here to be utilized by individual data types
use RPerl::DataType::Modifier::Reference;

1;  # end of package
