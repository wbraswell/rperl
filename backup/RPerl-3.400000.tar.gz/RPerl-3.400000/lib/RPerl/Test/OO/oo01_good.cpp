//!/usr/bin/rperl

























// [[[ HEADER ]]]
#include <rperlstandalone.h>
#ifndef __CPP__INCLUDED__RPerl__Test__OO__oo01_good_cpp
#define __CPP__INCLUDED__RPerl__Test__OO__oo01_good_cpp 0.001_000
# ifdef __CPP__TYPES




// [[[ INCLUDES ]]]
#include "RPerl/Test/OO/oo01_good.h"
int main() {
    // [[[ OPERATIONS HEADER ]]]

// [[[ OPERATIONS ]]]
    RPerl__Test__OO__MyClass01Good_ptr my_object = (NEW_RPerl__Test__OO__MyClass01Good {}).bar(22).NEW();
    print "have $my_object->get_bar() = " << my_object->get_bar() << endl;
    my_object->double_bar_save();
    print "have $my_object->get_bar() = " << my_object->get_bar() << endl;
    print "have $my_object->double_bar_return() = " << my_object->double_bar_return() << endl;
    print "have $my_object->get_bar() = " << my_object->get_bar() << endl;
    RPerl__Test__OO__MySubclass01Good_ptr my_object_subclass(new RPerl__Test__OO__MySubclass01Good);
    print "have $my_object_subclass->get_bar() = " << my_object_subclass->get_bar() << endl;
    print "have $my_object_subclass->get_bax() = " << my_object_subclass->get_bax() << endl;
    my_object_subclass->triple_bax_save();
    print "have $my_object_subclass->get_bax() = " << my_object_subclass->get_bax() << endl;
    print "have $my_object_subclass->triple_bax_return() = " << my_object_subclass->triple_bax_return() << endl;
    print "have $my_object_subclass->get_bax() = " << my_object_subclass->get_bax() << endl;
    print "have $my_object_subclass->multiply_bax_return(2) = " << my_object_subclass->multiply_bax_return(2) << endl;
    print "have $my_object_subclass->get_bax() = " << my_object_subclass->get_bax() << endl;
    print "have $my_object_subclass->multiply_bax_return(20) = " << my_object_subclass->multiply_bax_return(20) << endl;
    print "have $my_object_subclass->get_bax() = " << my_object_subclass->get_bax() << endl;
    RPerl__Test__OO__MySubclass01Good_ptr my_object_subclass2 = (NEW_RPerl__Test__OO__MySubclass01Good{}).bar(33).bax(88).NEW();
    print "have $my_object_subclass2->get_bar() = " << my_object_subclass2->get_bar() << endl;
    print "have $my_object_subclass2->get_bax() = " << my_object_subclass2->get_bax() << endl;
    my_object_subclass2->triple_bax_save();
    print "have $my_object_subclass2->get_bax() = " << my_object_subclass2->get_bax() << endl;
    print "have $my_object_subclass2->triple_bax_return() = " << my_object_subclass2->triple_bax_return() << endl;
    print "have $my_object_subclass2->get_bax() = " << my_object_subclass2->get_bax() << endl;
    print "have $my_object_subclass2->multiply_bax_return(2) = " << my_object_subclass2->multiply_bax_return(2) << endl;
    print "have $my_object_subclass2->get_bax() = " << my_object_subclass2->get_bax() << endl;
    print "have $my_object_subclass2->multiply_bax_return(20) = " << my_object_subclass2->multiply_bax_return(20) << endl;
    print "have $my_object_subclass2->get_bax() = " << my_object_subclass2->get_bax() << endl;















    // [[[ OPERATIONS FOOTER ]]]
    return 0;
}

// [[[ FOOTER ]]]
# elif defined __PERL__TYPES
Purposefully_die_from_a_compile-time_error,_due_to____PERL__TYPES_being_defined.__We_need_to_define_only___CPP__TYPES_in_this_file!
# endif
#endif
