#include "RPerl/Test/OO/MyClass01Good.cpp"
