#!/bin/bash
find . -name "_Inline" -type d -exec rm -rf {} +
