#!/usr/bin/env perl

# Program Name
# Program Description

# [[[ PREPROCESSOR ]]]
# ...

# [[[ HEADER ]]]
use RPerl;
use strict;
use warnings;
our $VERSION = 0.001_000;

# [[[ CRITICS ]]]
# ...

# [[[ INCLUDES ]]]
# ...

# [[[ CONSTANTS ]]]
# ...

# [[[ SUBROUTINES ]]]
# ...

# [[[ OPERATIONS ]]]
# ...