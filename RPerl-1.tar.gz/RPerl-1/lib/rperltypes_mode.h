#ifndef __CPP__INCLUDED__rperltypes_mode_h
#define __CPP__INCLUDED__rperltypes_mode_h 1

// AUTOMATICALLY MODIFIED BY rperltypes::types_enable()
// <<< TYPE DEFINES >>>
//#define __PERL__TYPES  // must choose exactly ONE of this,
#define __CPP__TYPES  // or this

#endif
