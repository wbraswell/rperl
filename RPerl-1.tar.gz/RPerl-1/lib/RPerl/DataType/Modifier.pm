use strict;  use warnings;
package RPerl::DataType::Modifier;

# RPerl Data Type, no inheritance from RPerl or RPerl::CompileUnit::Module::Class
1;