package RPerl::DataStructure::CodeReference;
use strict;
use warnings;
use RPerl;
our $VERSION = 0.000_002;

use parent qw(RPerl::DataStructure);
our %properties = (); ## no critic qw(ProhibitPackageVars)  # USER DEFAULT 2: allow OO properties

1;
