# [[[ HEADER ]]]
package RPerl::Test::DataTypeNumber::Number_47_Bad_01;
use strict;
use warnings;
use RPerl;
our $VERSION = 0.001_000;

our void $empty_sub = sub { -2333_456_789.234_56; };

1;
1;    # CODE SEPARATOR: end of package
