package RPerl::Test::Foo;
1, 1;
