# [[[ HEADER ]]]
package RPerl::Test::DataTypeString::String_DoubleQuotes_11_Good;
use strict;
use warnings;
use RPerl;
our $VERSION = 0.001_000;

# [[[ SUBROUTINES ]]]
our void $empty_sub = sub { "\t"; };

1;
1;    # CODE SEPARATOR: end of package
