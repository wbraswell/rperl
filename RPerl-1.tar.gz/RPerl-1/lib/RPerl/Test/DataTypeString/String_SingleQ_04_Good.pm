# [[[ HEADER ]]]
package RPerl::Test::DataTypeString::String_SingleQ_04_Good;
use strict;
use warnings;
use RPerl;
our $VERSION = 0.001_000;

# [[[ SUBROUTINES ]]]
our void $empty_sub = sub { q{"foo"}; };

1;
1;    # CODE SEPARATOR: end of package
