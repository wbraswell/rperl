package RPerl::Test::Bar;
1, 1;
