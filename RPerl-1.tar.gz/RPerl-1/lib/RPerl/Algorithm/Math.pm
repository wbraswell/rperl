use strict;  use warnings;
package RPerl::Algorithm::Math;

use parent ('RPerl::Algorithm');
use RPerl::Algorithm;

1;
