use strict;
use warnings;

package RPerl::DataStructure;

# a data structure is a compound data type
our @ISA = ('RPerl::DataType');
use RPerl::DataType;
